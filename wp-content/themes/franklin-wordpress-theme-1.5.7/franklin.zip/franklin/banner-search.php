<div class="banner">
	<div class="shadow-wrapper">
		<h1 class="banner-title"><?php _e( 'Search Results', 'franklin' ) ?></h1>
	</div>
</div>