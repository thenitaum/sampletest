			<div class="meta meta-below">
				<p class="center"><?php printf( _x( 'By %s', 'by author', 'franklin' ), '<a href="'.get_author_posts_url( get_the_author_meta('ID') ) .'">'.get_the_author().'</a>' ) ?></p>				
			</div>