<div class="banner">
	<div class="shadow-wrapper">
		<h1 class="banner-title"><?php _e( 'Edit Campaign', 'franklin' ) ?></h1>
	</div>
</div>