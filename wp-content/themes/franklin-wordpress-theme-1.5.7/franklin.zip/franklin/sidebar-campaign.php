<aside class="sidebar sidebar-campaign">

	<?php dynamic_sidebar('sidebar_campaign') ?>

</aside>
