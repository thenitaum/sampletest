<?php global $author ?>
<div class="banner">
	<div class="shadow-wrapper">
		<h1 class="banner-title"><?php echo $author->nickname ?></h1>		
	</div>
</div>
