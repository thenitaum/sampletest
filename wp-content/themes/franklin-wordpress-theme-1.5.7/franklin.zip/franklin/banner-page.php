<div class="banner">
	<div class="shadow-wrapper">
		<h1 class="banner-title"><?php the_title() ?></h1>
	</div>
</div>