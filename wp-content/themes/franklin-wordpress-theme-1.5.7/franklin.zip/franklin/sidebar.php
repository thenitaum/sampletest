<aside class="sidebar">

	<?php dynamic_sidebar('default') ?>

</aside>