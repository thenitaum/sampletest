<div class="edd_download_buy_button">
	<?php echo edd_get_purchase_link( array( 'download_id' => get_the_ID() ) ); ?>
</div>
